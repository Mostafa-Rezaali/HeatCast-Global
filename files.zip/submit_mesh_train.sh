#!/bin/bash
#SBATCH --job-name=cfm_mesh_gnn
#SBATCH --output=/blue/nessie/mostafarezaali/Teleconnection/slurm_logs/mesh_gnn_%j.log
#SBATCH --error=/blue/nessie/mostafarezaali/Teleconnection/slurm_logs/mesh_gnn_%j.err
#SBATCH --partition=hpg-b200
#SBATCH --qos=nessie
#SBATCH --nodes=1
#SBATCH --ntasks-per-node=8
#SBATCH --gpus-per-node=8
#SBATCH --cpus-per-task=4
#SBATCH --mem=250gb
#SBATCH --time=72:00:00

# ===========================================================================
# Environment
# ===========================================================================
module load conda
conda activate torch_b200

# NCCL fixes for B200 mixed InfiniBand/RoCE
export NCCL_IB_DISABLE=1
export NCCL_NVLS_ENABLE=0

# Prevent mmap page cache thrashing
export PYTORCH_CUDA_ALLOC_CONF=expandable_segments:True
export PYTHONUNBUFFERED=1

cd /blue/nessie/mostafarezaali/Teleconnection/

# Create log directory
mkdir -p slurm_logs

# ===========================================================================
# Pre-flight syntax check (saves queue time on indentation errors)
# ===========================================================================
echo "Running syntax check..."
python -c "import py_compile; py_compile.compile('cfm_mesh_train.py', doraise=True)" || {
    echo "SYNTAX ERROR in cfm_mesh_train.py - aborting"
    exit 1
}
echo "Syntax OK"

# ===========================================================================
# Four files must be in the same directory:
#   1. cfm_mesh_train.py    (main training script)
#   2. icosahedral_mesh.py  (mesh construction)
#   3. mesh_backbone.py     (GNN model)
#   4. mode_dispatch.py     (loss + sampling for both modes)
# ===========================================================================

# ===========================================================================
# MODE SELECTION: uncomment ONE of these two blocks
# ===========================================================================

# --- PROBABILISTIC (GenCast/CFM) - default ---
MODE_FLAG=""
MODE_NAME="GenCast (probabilistic CFM)"

# --- DETERMINISTIC (GraphCast) - uncomment to use ---
# MODE_FLAG="--deterministic"
# MODE_NAME="GraphCast (deterministic)"

echo "Starting training with 8x B200 GPUs..."
echo "Mode: ${MODE_NAME}"
echo "Mesh refinement level: 6"
echo "Processor rounds: 8"

torchrun \
    --standalone \
    --nproc_per_node=8 \
    cfm_mesh_train.py \
    --mode train \
    ${MODE_FLAG}

echo "Done."
